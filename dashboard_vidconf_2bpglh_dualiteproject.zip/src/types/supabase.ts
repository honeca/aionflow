export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      certificados: {
        Row: {
          apelido: string | null
          arquivo_nome: string | null
          arquivo_url: string | null
          created_at: string
          data_validade: string | null
          emitido_por: string | null
          empresa_id: string
          id: string
          senha: string | null
          status: string | null
          tipo: string | null
          updated_at: string
        }
        Insert: {
          apelido?: string | null
          arquivo_nome?: string | null
          arquivo_url?: string | null
          created_at?: string
          data_validade?: string | null
          emitido_por?: string | null
          empresa_id: string
          id?: string
          senha?: string | null
          status?: string | null
          tipo?: string | null
          updated_at?: string
        }
        Update: {
          apelido?: string | null
          arquivo_nome?: string | null
          arquivo_url?: string | null
          created_at?: string
          data_validade?: string | null
          emitido_por?: string | null
          empresa_id?: string
          id?: string
          senha?: string | null
          status?: string | null
          tipo?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "certificados_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      empresas: {
        Row: {
          bairro: string | null
          capital_social: number | null
          cep: string | null
          cidade: string | null
          cnae: string | null
          cnpj: string | null
          complemento: string | null
          created_at: string
          data_abertura: string | null
          email1: string | null
          email2: string | null
          email3: string | null
          id: string
          ie: string | null
          im: string | null
          logradouro: string | null
          nome_fantasia: string | null
          numero: string | null
          razao_social: string | null
          regime_tributario: string | null
          responsavel_cpf: string | null
          responsavel_data_emissao_rg: string | null
          responsavel_email: string | null
          responsavel_funcao: string | null
          responsavel_nome: string | null
          responsavel_orgao_emissor: string | null
          responsavel_rg: string | null
          responsavel_telefone: string | null
          status: string | null
          telefone1: string | null
          telefone2: string | null
          telefone3: string | null
          uf: string | null
          updated_at: string
        }
        Insert: {
          bairro?: string | null
          capital_social?: number | null
          cep?: string | null
          cidade?: string | null
          cnae?: string | null
          cnpj?: string | null
          complemento?: string | null
          created_at?: string
          data_abertura?: string | null
          email1?: string | null
          email2?: string | null
          email3?: string | null
          id?: string
          ie?: string | null
          im?: string | null
          logradouro?: string | null
          nome_fantasia?: string | null
          numero?: string | null
          razao_social?: string | null
          regime_tributario?: string | null
          responsavel_cpf?: string | null
          responsavel_data_emissao_rg?: string | null
          responsavel_email?: string | null
          responsavel_funcao?: string | null
          responsavel_nome?: string | null
          responsavel_orgao_emissor?: string | null
          responsavel_rg?: string | null
          responsavel_telefone?: string | null
          status?: string | null
          telefone1?: string | null
          telefone2?: string | null
          telefone3?: string | null
          uf?: string | null
          updated_at?: string
        }
        Update: {
          bairro?: string | null
          capital_social?: number | null
          cep?: string | null
          cidade?: string | null
          cnae?: string | null
          cnpj?: string | null
          complemento?: string | null
          created_at?: string
          data_abertura?: string | null
          email1?: string | null
          email2?: string | null
          email3?: string | null
          id?: string
          ie?: string | null
          im?: string | null
          logradouro?: string | null
          nome_fantasia?: string | null
          numero?: string | null
          razao_social?: string | null
          regime_tributario?: string | null
          responsavel_cpf?: string | null
          responsavel_data_emissao_rg?: string | null
          responsavel_email?: string | null
          responsavel_funcao?: string | null
          responsavel_nome?: string | null
          responsavel_orgao_emissor?: string | null
          responsavel_rg?: string | null
          responsavel_telefone?: string | null
          status?: string | null
          telefone1?: string | null
          telefone2?: string | null
          telefone3?: string | null
          uf?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      socios: {
        Row: {
          cpf: string | null
          created_at: string
          data_entrada: string | null
          empresa_id: string
          funcao: string | null
          id: string
          nome: string | null
          participacao: number | null
          status: string | null
          updated_at: string
          valor_integralizado: number | null
        }
        Insert: {
          cpf?: string | null
          created_at?: string
          data_entrada?: string | null
          empresa_id: string
          funcao?: string | null
          id?: string
          nome?: string | null
          participacao?: number | null
          status?: string | null
          updated_at?: string
          valor_integralizado?: number | null
        }
        Update: {
          cpf?: string | null
          created_at?: string
          data_entrada?: string | null
          empresa_id?: string
          funcao?: string | null
          id?: string
          nome?: string | null
          participacao?: number | null
          status?: string | null
          updated_at?: string
          valor_integralizado?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "socios_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

export type Tables<
  PublicTableNameOrOptions extends
    | keyof (Database["public"]["Tables"] & Database["public"]["Views"])
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
        Database[PublicTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
      Database[PublicTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : PublicTableNameOrOptions extends keyof (Database["public"]["Tables"] &
        Database["public"]["Views"])
    ? (Database["public"]["Tables"] &
        Database["public"]["Views"])[PublicTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  PublicTableNameOrOptions extends
    | keyof Database["public"]["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : PublicTableNameOrOptions extends keyof Database["public"]["Tables"]
    ? Database["public"]["Tables"][PublicTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  PublicTableNameOrOptions extends
    | keyof Database["public"]["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : PublicTableNameOrOptions extends keyof Database["public"]["Tables"]
    ? Database["public"]["Tables"][PublicTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  PublicEnumNameOrOptions extends
    | keyof Database["public"]["Enums"]
    | { schema: keyof Database },
  EnumName extends PublicEnumNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = PublicEnumNameOrOptions extends { schema: keyof Database }
  ? Database[PublicEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : PublicEnumNameOrOptions extends keyof Database["public"]["Enums"]
    ? Database["public"]["Enums"][PublicEnumNameOrOptions]
    : never
